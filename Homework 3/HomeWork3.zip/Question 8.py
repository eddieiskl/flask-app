with open('words.txt', 'w') as file:
    file.write("Your Name")