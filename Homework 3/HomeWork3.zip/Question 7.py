with open('words.txt', 'w') as file:
    pass  # Creates an empty file

#open('words.txt', 'w') opens the file in write mode, creating it if it does not exist.
#pass is a placeholder indicating no action is taken inside the with block.