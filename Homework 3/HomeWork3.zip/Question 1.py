# This code will raise a ZeroDivisionError
a = 1 / 0