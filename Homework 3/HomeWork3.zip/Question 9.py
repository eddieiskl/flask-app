with open('words.txt', 'r') as file:
    content = file.read()
    print(content)