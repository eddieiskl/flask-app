# Part G
# Step 1: Method to print "hello"
def printHello():
    print("hello")

# Step 2: Method to add 5 + 3.2 and print the result
def calculate():
    result = 5 + 3.2
    print("The result of 5 + 3.2 is:", result)

# Calling the methods
printHello()
calculate()