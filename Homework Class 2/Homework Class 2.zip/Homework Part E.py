# Part E
# Step 1: Create variables
age = 41  # Your age
first_letter_last_name = 'I'  # First letter of your last name
shekel_dollar_currency = 3.8  # Current shekels-dollar currency
flew_abroad = True  # Did you fly abroad (True/False)
apartment_number = 10  # Your apartment number

# Step 2: Print all variables
print("Age:", age)
print("First letter of last name:", first_letter_last_name)
print("Shekel-Dollar currency:", shekel_dollar_currency)
print("Flew abroad:", flew_abroad)
print("Apartment number:", apartment_number)

# Step 3: Add the currency to your age and check the result
result = age + shekel_dollar_currency
print("Result of adding age and currency:", result)