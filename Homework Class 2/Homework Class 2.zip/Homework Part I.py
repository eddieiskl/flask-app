# Part I
# Step 1: Method to receive two numbers, add them, and return the sum
def addNumbers(a, b):
    return a + b

# Step 2: Method to receive two strings, add space between them, and return one spaced string
def addStrings(str1, str2):
    return str1 + " " + str2

# Calling the methods
sum_result = addNumbers(5, 7)
print("Sum of numbers:", sum_result)

spaced_string = addStrings("Hello", "World")
print("Spaced string:", spaced_string)