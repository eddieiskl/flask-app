# Part F
# Step 1: Ask user for their phone number
phone_number = input("Please enter your phone number: ")

# Step 2: Print the words "phone number" and the user's phone number
print("Phone number:", phone_number)