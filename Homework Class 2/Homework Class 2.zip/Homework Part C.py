# Part C
# Step 1: Create a variable and initialize it with a number 1-4
season_number = 4  # You can change this value between 1 and 4

# Step 2 and 3: Check the variable and print the season name
if season_number == 1:
    print("summer")
elif season_number == 2:
    print("winter")
elif season_number == 3:
    print("fall")
elif season_number == 4:
    print("spring")
else:
    print("Invalid season number")