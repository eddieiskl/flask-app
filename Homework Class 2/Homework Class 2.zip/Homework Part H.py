# Part H
# Step 1: Method to receive your name and print it
def printName(name):
    print("Your name is:", name)

# Step 2: Method to receive a number, divide it by 2, and print the result
def divideByTwo(number):
    result = number / 2
    print("Half of", number, "is:", result)

# Calling the methods
printName("John Doe")  # Replace with your name
divideByTwo(10)  # Replace with any number