# Part A
# Step 1: Create two variables X and Y
X = 10  # You can change the value to any number
Y = 10   # You can change the value to any number

# Step 2 and 3: Compare the variables and print accordingly
if X > Y:
    print("BIG")
elif X < Y:
    print("small")
else:
    print("X is equal to Y")