# Part B
# Step 1 and 2: Run a for loop 5 times and print iteration number
for i in range(5):
    print("Iteration number:", i)