# MainGame.py
# This file is not necessary for running the Flask app

if __name__ == "__main__":
    print("This script is not needed for the Flask application. Please run app.py instead.")