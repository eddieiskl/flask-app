# app.py
from flask import Flask, render_template, request, redirect, url_for
from Live import welcome, load_game
from GuessGame import GuessGame
from MemoryGame import MemoryGame
from CurrencyRouletteGame import CurrencyRouletteGame

app = Flask(__name__)

player_name = ""
last_game = None
last_difficulty = None

@app.route("/", methods=["GET", "POST"])
def index():
    global player_name
    if request.method == "POST":
        player_name = request.form.get("player_name")
        if player_name.lower() == 'q':
            return render_template("quit.html")
        return redirect(url_for("menu"))
    return render_template("index.html")

@app.route("/menu", methods=["GET", "POST"])
def menu():
    global last_game, last_difficulty
    if request.method == "POST":
        game_choice = request.form.get("game_choice")
        if game_choice == 'q':
            return render_template("quit.html")
        difficulty = request.form.get("difficulty")
        if difficulty == 'q':
            return render_template("quit.html")
        if game_choice.isdigit() and difficulty.isdigit():
            last_game = int(game_choice)
            last_difficulty = int(difficulty)
            return redirect(url_for("play_game"))
    return render_template("menu.html", welcome_message=welcome(player_name))

@app.route("/play", methods=["GET", "POST"])
def play_game():
    global last_game, last_difficulty
    game = None
    if last_game == 1:
        game = MemoryGame(player_name, last_difficulty)
    elif last_game == 2:
        game = GuessGame(player_name, last_difficulty)
    elif last_game == 3:
        game = CurrencyRouletteGame(player_name, last_difficulty)

    if request.method == "POST":
        user_input = request.form.get("user_input")
        if user_input == 'q':
            return render_template("quit.html")
        if game.play(user_input):
            return render_template("result.html", result="won", correct_answer=game.secret_number)
        else:
            return render_template("result.html", result="lost", correct_answer=game.secret_number)

    return render_template("game.html", game=game)

@app.route("/result", methods=["GET", "POST"])
def result():
    if request.method == "POST":
        choice = request.form.get("choice")
        if choice == 'q':
            return render_template("quit.html")
        elif choice == 'm':
            return redirect(url_for("menu"))
        elif choice == 'r':
            return redirect(url_for("play_game"))
    return render_template("result.html")

if __name__ == "__main__":
    app.run(debug=True)