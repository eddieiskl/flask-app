# Live.py

def welcome(name):
    """
    This function takes a person's name as an input and returns a welcome string.
    """
    return f"Hello {name} and welcome to the World of Games (WoG).\nHere you can find many cool games to play."


def load_game():
    """
    This function prints out game options and asks the user to choose a game and its difficulty level.
    """
    print("Please choose a game to play:")
    print("1. Memory Game - a sequence of numbers will appear for 1 second and you have to guess it back")
    print("2. Guess Game - guess a number and see if you chose like the computer")
    print("3. Currency Roulette - try and guess the value of a random amount of USD in ILS")

    game_choice = input("Enter the number of the game you want to play: ")
    while not game_choice.isdigit() or not (1 <= int(game_choice) <= 3):
        game_choice = input("Invalid input. Please enter a number between 1 and 3: ")

    difficulty = input("Please choose game difficulty from 1 to 5: ")
    while not difficulty.isdigit() or not (1 <= int(difficulty) <= 5):
        difficulty = input("Invalid input. Please enter a number between 1 and 5: ")

    print(f"You chose game {game_choice} with difficulty level {difficulty}.")