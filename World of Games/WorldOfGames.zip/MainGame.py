# MainGame.py
from Live import load_game, welcome

if __name__ == "__main__":
    print(welcome("Eddie"))
    load_game()